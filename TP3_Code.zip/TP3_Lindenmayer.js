TP3.Lindenmayer = {
	
	iterateGrammar: function (str, dict, iters) {
		//TODO
	},
	
	iterateGrammarProb: function (str, dict, iters) {
		//TODO
	}
	
};